#Data consists accidents
data = read.csv("datavehicle.csv")
noveh=data$Number.of.Vehicles
noca=data$Number.of.Casualties
age=data$Age.of.Casualty
typev=data$Type.of.Vehicle

#Scatter plot showing relation between age and number of casuality
plot(x=age,y=noca,
     col="darkgreen",
     main="Age and number of casuality",
     xlab="Age",
     ylab="Number of casuality")

m=mean(noca)
print(m)
s=sd(noca)
print(s)


#Normal Distribution graph of Total number of accidents
x=noca
y <- dnorm(x, mean = 2.090909, sd = 1.512471)
plot(x,y, main = "Total number of accidents", col = "maroon")


#Correlation between the Number of vehicle and Number of casuality
correlation=cor(noveh,noca,method = "pearson")
print(c("Karl Pearson's correlation coefficient is :",correlation))
if(correlation==0)
  print("Independant correlation")
if(correlation<0)
  print("Negative correlation")
if(correlation>0)
  print("Positive correlation")


#Regression between type of vehicle and number of casuality
x=typev
y=noca
relation=lm(y~x)
plot(x,y,main="Type of vehicle and Number of casuality",xlab="type vehicle",ylab = "Number casuality")
print(relation)



#histogram
hist(datavehicle$Grid.Ref..Northing,main="Histogram of Accidents in North",xlab="accidents",col=terrain.colors(5))
hist(datavehicle$Grid.Ref..Easting,main="Histogram of Accidents in East",xlab="accidents",col=rainbow(5))

